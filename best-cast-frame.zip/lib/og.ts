export function getOgImageUrl(casts: any[]) {
  return `https://og-image.vercel.app/Best%20Cast.png?theme=dark&md=1&fontSize=100px&images=https://farcaster.network/favicon.ico`;
}